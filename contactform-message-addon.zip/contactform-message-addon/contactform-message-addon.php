<?php
/**
 * Contactform Message Addon
 *
 * @package     Contactform Message Addon
 * @author      CMS Minds
 * @copyright   2022 CMS Minds
 * @license     GPL-2.0-or-later
 *
 * @wordpress-plugin
 * Plugin Name: Contactform Message Addon
 * Plugin URI:  https://testing.com/our_plugins
 * Description: This plugin add new message to contact form 7 and also work according to that.
 * Version:     1.0.0
 * Author:      CMS Minds
 * Author URI:  https://testing.com/
 * Text Domain: contactform_message_addon
 * License:     GPL v2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.txt
 */

include_once("functions.php");

?>
