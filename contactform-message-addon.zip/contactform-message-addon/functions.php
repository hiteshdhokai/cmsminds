<?php
add_filter( 'wpcf7_messages', 'mywpcf7_text_messages' );
function mywpcf7_text_messages( $messages ) {
    return array_merge( $messages, array(
        'invalid_name' => array(
            'description' => __( "Only cmsMinds emails are allowed.", 'contact-form-7' ),
            'default' => __( 'You can only enter the email with the domain, cmsminds.com', 'contact-form-7' )
        )
    ));
}

function my_wpcf7_validate_email( $result, $tag ) {
	
    $type = $tag['type'];
    $email = $tag['name'];
    $value = $_POST[$email] ;

    if ( strpos( $email , 'email' ) !== false ){
        $value = trim($value);
        $Valid = substr($value, -13) === '@cmsminds.com';
        if ( $Valid < 1 ) {
            $result->invalidate( $tag, wpcf7_get_message( 'invalid_name' ) );
        }
    }
    return $result;
}
add_filter( 'wpcf7_validate_email*', 'my_wpcf7_validate_email' , 10, 2 );

?>
